//! [0]
button.text = qsTr('Hello World!');
button.styleSheet = 'font-style: italic';
button.show();
//! [0]
