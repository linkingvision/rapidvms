function () {
}

0 = 1;

