qsTrId("qtn_foo_bar");

var more_greeting_strings = [ QT_TRID_NOOP("qtn_needle"), QT_TRID_NOOP("qtn_haystack") ];

qsTrId("qtn_bar_baz", 10);
