<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nb_NO">
<context>
    <name></name>
    <message id="qtn_foo_bar">
        <location filename="idtranslatable.js" line="1"/>
        <source></source>
        <translation>First string</translation>
    </message>
    <message id="qtn_needle">
        <location filename="idtranslatable.js" line="3"/>
        <source></source>
        <translation>Second string</translation>
    </message>
    <message id="qtn_haystack">
        <location filename="idtranslatable.js" line="3"/>
        <source></source>
        <translation>Third string</translation>
    </message>
    <message id="qtn_bar_baz" numerus="yes">
        <location filename="idtranslatable.js" line="5"/>
        <source></source>
        <translation>
            <numerusform>Fourth string</numerusform>
            <numerusform>%n fooish bar(s) found</numerusform>
        </translation>
    </message>
</context>
</TS>
