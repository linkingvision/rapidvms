<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nb_NO">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name></name>
    <message id="Ǹǒƙǐǡ">
        <location filename="idtranslatable-unicode.js" line="1"/>
        <source></source>
        <translation>Ƨưƈȼȝȿș</translation>
    </message>
    <message id="ƑǎȑȩƜƎƚǐ">
        <location filename="idtranslatable-unicode.js" line="3"/>
        <source></source>
        <translation>Ǡȡȋȅȕ</translation>
    </message>
    <message id="ƁơȓƏƌ" numerus="yes">
        <location filename="idtranslatable-unicode.js" line="5"/>
        <source></source>
        <translation>
            <numerusform>Ƒưǹ</numerusform>
            <numerusform>%n ƒơǒ(ș)</numerusform>
        </translation>
    </message>
</context>
</TS>
