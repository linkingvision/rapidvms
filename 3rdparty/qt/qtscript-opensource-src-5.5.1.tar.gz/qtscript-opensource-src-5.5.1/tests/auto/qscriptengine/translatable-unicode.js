qsTr("H\u2082O");
qsTranslate("\u010C\u0101\u011F\u0115", "CO\u2082");

var unicode_strings = [
    QT_TR_NOOP("\u0391\u0392\u0393"),
    QT_TRANSLATE_NOOP("\u010C\u0101\u011F\u0115", "\u0414\u0415\u0416")
];

qsTr("H\u2082O", "not the same H\u2082O");
