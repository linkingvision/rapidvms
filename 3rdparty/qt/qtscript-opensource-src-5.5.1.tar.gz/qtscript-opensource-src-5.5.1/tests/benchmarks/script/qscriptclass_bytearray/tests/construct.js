for (i = 0; i < 5000; ++i)
    new ByteArray(123);
