ba = new ByteArray();
for (i = 0; i < 10000; ++i)
    ba.length = 123;
