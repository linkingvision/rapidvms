ba = new ByteArray(123);
for (i = 0; i < 3000; ++i)
    ba.trimmed();
