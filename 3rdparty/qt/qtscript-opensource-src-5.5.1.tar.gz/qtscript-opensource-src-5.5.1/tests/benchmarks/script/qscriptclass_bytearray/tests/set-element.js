ba = new ByteArray(123);
for (i = 0; i < 10000; ++i)
    ba[10] = 123;
