ba = new ByteArray(123);
for (i = 0; i < 5000; ++i)
    new ByteArray(ba);
