ba = new ByteArray(8000);
for (var p in ba)
    ;
