#include "../../../../../src/scripttools/debugging/qscriptedit_p.h"
