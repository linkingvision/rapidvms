#include "../../../../../src/scripttools/debugging/qscriptdebuggerstackwidgetinterface_p_p.h"
