#include "../../../../../src/scripttools/debugging/qscriptdebuggerconsolewidgetinterface_p.h"
