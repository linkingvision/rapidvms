#include "../../../../../src/scripttools/debugging/qscriptdebuggerstandardwidgetfactory_p.h"
