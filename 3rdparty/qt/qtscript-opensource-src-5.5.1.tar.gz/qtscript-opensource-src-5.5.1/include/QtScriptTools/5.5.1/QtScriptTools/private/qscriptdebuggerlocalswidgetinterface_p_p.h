#include "../../../../../src/scripttools/debugging/qscriptdebuggerlocalswidgetinterface_p_p.h"
