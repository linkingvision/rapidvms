#include "../../../../../src/scripttools/debugging/qscriptsyntaxhighlighter_p.h"
