#include "../../../../../src/scripttools/debugging/qscriptdebuggerconsolecommand_p.h"
