#include "../../../../../src/scripttools/debugging/qscriptdebuggerlocalswidget_p.h"
