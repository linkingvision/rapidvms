#include "../../../../../src/scripttools/debugging/qscriptdebuggerscriptswidget_p.h"
