#include "../../../../../src/scripttools/debugging/qscripterrorlogwidget_p.h"
