#include "../../../../../src/scripttools/debugging/qscripterrorlogwidgetinterface_p.h"
