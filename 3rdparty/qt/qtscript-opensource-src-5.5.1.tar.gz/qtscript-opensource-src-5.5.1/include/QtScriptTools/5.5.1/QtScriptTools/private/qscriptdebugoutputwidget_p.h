#include "../../../../../src/scripttools/debugging/qscriptdebugoutputwidget_p.h"
