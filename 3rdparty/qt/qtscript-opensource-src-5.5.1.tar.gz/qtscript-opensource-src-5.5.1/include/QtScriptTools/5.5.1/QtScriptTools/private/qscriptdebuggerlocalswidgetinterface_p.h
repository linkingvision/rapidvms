#include "../../../../../src/scripttools/debugging/qscriptdebuggerlocalswidgetinterface_p.h"
