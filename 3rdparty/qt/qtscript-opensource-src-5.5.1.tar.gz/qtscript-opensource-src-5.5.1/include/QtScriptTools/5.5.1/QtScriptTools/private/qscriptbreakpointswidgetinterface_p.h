#include "../../../../../src/scripttools/debugging/qscriptbreakpointswidgetinterface_p.h"
