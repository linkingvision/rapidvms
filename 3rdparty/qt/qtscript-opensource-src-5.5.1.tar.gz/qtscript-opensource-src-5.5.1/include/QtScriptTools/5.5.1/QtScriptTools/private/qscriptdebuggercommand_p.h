#include "../../../../../src/scripttools/debugging/qscriptdebuggercommand_p.h"
