#include "../../../../../src/scripttools/debugging/qscriptdebuggerconsolewidgetinterface_p_p.h"
