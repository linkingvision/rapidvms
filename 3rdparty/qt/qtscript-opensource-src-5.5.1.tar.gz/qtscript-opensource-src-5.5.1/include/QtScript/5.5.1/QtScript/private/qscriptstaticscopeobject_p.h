#include "../../../../../src/script/bridge/qscriptstaticscopeobject_p.h"
