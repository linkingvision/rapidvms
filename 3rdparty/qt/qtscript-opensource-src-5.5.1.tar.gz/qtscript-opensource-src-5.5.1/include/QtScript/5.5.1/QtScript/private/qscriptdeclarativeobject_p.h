#include "../../../../../src/script/bridge/qscriptdeclarativeobject_p.h"
