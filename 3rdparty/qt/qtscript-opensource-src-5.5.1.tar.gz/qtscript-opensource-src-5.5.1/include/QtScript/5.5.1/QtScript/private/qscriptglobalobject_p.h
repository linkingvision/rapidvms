#include "../../../../../src/script/bridge/qscriptglobalobject_p.h"
