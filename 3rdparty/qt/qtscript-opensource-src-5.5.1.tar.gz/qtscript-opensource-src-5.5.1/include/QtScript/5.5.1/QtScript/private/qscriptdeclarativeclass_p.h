#include "../../../../../src/script/bridge/qscriptdeclarativeclass_p.h"
