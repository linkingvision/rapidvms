#include "../../../../../src/script/bridge/qscriptqobject_p.h"
