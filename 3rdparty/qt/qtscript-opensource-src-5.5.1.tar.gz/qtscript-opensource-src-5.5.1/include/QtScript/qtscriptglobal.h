#include "../../src/script/api/qtscriptglobal.h"
