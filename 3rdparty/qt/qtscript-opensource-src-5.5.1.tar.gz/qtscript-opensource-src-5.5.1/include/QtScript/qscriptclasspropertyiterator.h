#include "../../src/script/api/qscriptclasspropertyiterator.h"
