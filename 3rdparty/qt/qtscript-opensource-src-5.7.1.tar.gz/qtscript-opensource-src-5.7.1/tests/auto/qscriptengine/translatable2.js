qsTr("Three");
qsTranslate("BarContext", "Four");

var celebration_strings = [
    QT_TR_NOOP("Happy birthday!"),
    QT_TRANSLATE_NOOP("BarContext", "Congratulations!")
];

qsTr("Three", "not the same three");
