<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>translatable-unicode</name>
    <message>
        <location filename="translatable-unicode.js" line="1"/>
        <source>H₂O</source>
        <translation>ͻͼͽ</translation>
    </message>
    <message>
        <location filename="translatable-unicode.js" line="5"/>
        <source>ΑΒΓ</source>
        <translation>ӜҴѼ</translation>
    </message>
    <message>
        <location filename="translatable-unicode.js" line="9"/>
        <source>H₂O</source>
        <comment>not the same H₂O</comment>
        <translation>ԶՊՒ</translation>
    </message>
</context>
<context>
    <name>Čāğĕ</name>
    <message>
        <location filename="translatable-unicode.js" line="2"/>
        <source>CO₂</source>
        <translation>בךע</translation>
    </message>
    <message>
        <location filename="translatable-unicode.js" line="6"/>
        <source>ДЕЖ</source>
        <translation>خسس</translation>
    </message>
</context>
</TS>
