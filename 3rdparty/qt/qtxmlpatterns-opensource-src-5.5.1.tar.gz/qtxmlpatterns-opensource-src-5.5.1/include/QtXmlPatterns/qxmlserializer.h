#include "../../src/xmlpatterns/api/qxmlserializer.h"
