#include "../../src/xmlpatterns/api/qabstractxmlreceiver.h"
