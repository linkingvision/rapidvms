#include "../../src/xmlpatterns/api/qabstractxmlnodemodel.h"
