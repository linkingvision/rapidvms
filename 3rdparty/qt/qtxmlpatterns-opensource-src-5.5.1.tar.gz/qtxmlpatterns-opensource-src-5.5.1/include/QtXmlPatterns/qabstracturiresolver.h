#include "../../src/xmlpatterns/api/qabstracturiresolver.h"
