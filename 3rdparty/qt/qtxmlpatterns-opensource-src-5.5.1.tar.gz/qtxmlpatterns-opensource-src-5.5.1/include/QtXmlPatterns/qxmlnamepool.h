#include "../../src/xmlpatterns/api/qxmlnamepool.h"
