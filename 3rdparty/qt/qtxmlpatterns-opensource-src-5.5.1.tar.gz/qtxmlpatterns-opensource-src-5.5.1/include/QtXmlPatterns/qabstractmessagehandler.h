#include "../../src/xmlpatterns/api/qabstractmessagehandler.h"
