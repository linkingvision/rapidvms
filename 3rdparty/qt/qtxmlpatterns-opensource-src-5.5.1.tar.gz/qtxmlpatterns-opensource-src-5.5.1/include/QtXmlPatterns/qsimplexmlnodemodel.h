#include "../../src/xmlpatterns/api/qsimplexmlnodemodel.h"
