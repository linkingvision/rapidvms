#include "../../../../../src/xmlpatterns/functions/qcomparescaseaware_p.h"
