#include "../../../../../src/xmlpatterns/expr/qstaticcompatibilitystore_p.h"
