#include "../../../../../src/xmlpatterns/schema/qxsdattributeterm_p.h"
