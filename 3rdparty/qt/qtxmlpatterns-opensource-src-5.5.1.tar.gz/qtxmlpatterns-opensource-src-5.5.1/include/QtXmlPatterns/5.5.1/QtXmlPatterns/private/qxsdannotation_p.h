#include "../../../../../src/xmlpatterns/schema/qxsdannotation_p.h"
