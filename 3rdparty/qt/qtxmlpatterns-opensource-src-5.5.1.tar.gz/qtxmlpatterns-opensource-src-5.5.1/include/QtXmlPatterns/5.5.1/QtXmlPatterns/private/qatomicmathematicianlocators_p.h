#include "../../../../../src/xmlpatterns/type/qatomicmathematicianlocators_p.h"
