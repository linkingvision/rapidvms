#include "../../../../../src/xmlpatterns/expr/qliteralsequence_p.h"
