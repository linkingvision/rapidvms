#include "../../../../../src/xmlpatterns/functions/qstaticnamespacescontainer_p.h"
