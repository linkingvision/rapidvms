#include "../../../../../src/xmlpatterns/data/qderivedstring_p.h"
