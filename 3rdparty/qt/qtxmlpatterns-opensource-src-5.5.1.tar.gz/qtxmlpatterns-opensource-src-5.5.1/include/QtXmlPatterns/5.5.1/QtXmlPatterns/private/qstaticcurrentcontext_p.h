#include "../../../../../src/xmlpatterns/environment/qstaticcurrentcontext_p.h"
