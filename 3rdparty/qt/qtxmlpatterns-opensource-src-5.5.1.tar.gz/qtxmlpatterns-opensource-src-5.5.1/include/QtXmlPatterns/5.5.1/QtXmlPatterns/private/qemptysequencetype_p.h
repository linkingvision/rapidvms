#include "../../../../../src/xmlpatterns/type/qemptysequencetype_p.h"
