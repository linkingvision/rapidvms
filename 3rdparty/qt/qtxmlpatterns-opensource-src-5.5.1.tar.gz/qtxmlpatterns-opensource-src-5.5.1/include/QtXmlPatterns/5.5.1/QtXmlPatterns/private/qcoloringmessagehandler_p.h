#include "../../../../../src/xmlpatterns/api/qcoloringmessagehandler_p.h"
