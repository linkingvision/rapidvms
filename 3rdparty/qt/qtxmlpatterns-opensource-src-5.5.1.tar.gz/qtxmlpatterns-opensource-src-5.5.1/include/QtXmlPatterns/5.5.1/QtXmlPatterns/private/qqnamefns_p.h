#include "../../../../../src/xmlpatterns/functions/qqnamefns_p.h"
