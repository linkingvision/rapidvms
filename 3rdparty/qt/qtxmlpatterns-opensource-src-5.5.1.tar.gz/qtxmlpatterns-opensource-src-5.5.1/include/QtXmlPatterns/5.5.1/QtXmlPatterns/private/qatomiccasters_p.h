#include "../../../../../src/xmlpatterns/data/qatomiccasters_p.h"
