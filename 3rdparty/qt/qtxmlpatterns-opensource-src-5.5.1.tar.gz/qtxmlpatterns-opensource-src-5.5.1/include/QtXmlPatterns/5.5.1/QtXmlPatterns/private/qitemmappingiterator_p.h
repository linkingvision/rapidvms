#include "../../../../../src/xmlpatterns/iterators/qitemmappingiterator_p.h"
