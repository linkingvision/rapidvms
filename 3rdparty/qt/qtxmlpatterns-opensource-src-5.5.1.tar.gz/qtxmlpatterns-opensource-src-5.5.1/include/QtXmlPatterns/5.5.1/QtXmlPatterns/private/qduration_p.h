#include "../../../../../src/xmlpatterns/data/qduration_p.h"
