#include "../../../../../src/xmlpatterns/functions/qsequencefns_p.h"
