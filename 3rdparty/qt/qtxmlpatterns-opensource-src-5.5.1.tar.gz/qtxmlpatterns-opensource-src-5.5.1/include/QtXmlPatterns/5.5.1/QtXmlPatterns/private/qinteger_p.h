#include "../../../../../src/xmlpatterns/data/qinteger_p.h"
