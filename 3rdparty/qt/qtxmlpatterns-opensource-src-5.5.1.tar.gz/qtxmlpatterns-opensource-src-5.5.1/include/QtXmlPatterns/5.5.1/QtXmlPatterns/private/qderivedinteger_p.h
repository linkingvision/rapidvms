#include "../../../../../src/xmlpatterns/data/qderivedinteger_p.h"
