#include "../../../../../src/xmlpatterns/schema/qxsdsimpletype_p.h"
