#include "../../../../../src/xmlpatterns/schema/qxsdschema_p.h"
