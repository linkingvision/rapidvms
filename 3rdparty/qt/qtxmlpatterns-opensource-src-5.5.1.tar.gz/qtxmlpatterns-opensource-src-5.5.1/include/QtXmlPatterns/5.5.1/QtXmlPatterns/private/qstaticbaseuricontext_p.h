#include "../../../../../src/xmlpatterns/environment/qstaticbaseuricontext_p.h"
