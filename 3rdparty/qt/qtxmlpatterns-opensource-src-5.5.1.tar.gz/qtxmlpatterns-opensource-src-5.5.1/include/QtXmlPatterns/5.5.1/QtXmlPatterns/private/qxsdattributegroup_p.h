#include "../../../../../src/xmlpatterns/schema/qxsdattributegroup_p.h"
