#include "../../../../../src/xmlpatterns/type/qnamedschemacomponent_p.h"
