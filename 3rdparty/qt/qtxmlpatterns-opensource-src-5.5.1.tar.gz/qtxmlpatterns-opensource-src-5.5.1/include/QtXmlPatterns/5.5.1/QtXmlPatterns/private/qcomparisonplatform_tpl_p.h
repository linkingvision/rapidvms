#include "../../../../../src/xmlpatterns/expr/qcomparisonplatform_tpl_p.h"
