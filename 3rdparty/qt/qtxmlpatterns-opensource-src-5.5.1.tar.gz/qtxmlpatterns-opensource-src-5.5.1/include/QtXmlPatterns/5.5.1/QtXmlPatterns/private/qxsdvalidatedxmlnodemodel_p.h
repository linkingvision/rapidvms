#include "../../../../../src/xmlpatterns/schema/qxsdvalidatedxmlnodemodel_p.h"
