#include "../../../../../src/xmlpatterns/schema/qxsdschemaparser_p.h"
