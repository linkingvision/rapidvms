#include "../../../../../src/xmlpatterns/data/qsequencereceiver_p.h"
