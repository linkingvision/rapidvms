#include "../../../../../src/xmlpatterns/functions/qtypeavailablefn_p.h"
