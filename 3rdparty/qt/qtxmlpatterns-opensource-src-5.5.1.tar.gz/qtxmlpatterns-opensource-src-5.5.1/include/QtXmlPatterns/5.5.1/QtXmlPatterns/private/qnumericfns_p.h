#include "../../../../../src/xmlpatterns/functions/qnumericfns_p.h"
