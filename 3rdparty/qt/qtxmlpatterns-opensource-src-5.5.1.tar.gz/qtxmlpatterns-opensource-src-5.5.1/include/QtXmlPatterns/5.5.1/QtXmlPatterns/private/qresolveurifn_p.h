#include "../../../../../src/xmlpatterns/functions/qresolveurifn_p.h"
