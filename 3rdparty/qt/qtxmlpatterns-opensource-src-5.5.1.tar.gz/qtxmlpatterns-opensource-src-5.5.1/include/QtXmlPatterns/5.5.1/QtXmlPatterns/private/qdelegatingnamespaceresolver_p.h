#include "../../../../../src/xmlpatterns/utils/qdelegatingnamespaceresolver_p.h"
