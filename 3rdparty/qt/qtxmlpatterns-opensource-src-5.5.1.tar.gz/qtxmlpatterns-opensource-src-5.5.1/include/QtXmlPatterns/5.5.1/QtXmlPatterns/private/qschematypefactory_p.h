#include "../../../../../src/xmlpatterns/type/qschematypefactory_p.h"
