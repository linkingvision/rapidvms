#include "../../../../../src/xmlpatterns/schema/qxsduserschematype_p.h"
