#include "../../../../../src/xmlpatterns/functions/qaggregatefns_p.h"
