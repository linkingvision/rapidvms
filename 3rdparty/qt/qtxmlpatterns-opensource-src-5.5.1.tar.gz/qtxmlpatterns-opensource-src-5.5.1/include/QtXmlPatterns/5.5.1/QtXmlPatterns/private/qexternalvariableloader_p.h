#include "../../../../../src/xmlpatterns/expr/qexternalvariableloader_p.h"
