#include "../../../../../src/xmlpatterns/schema/qxsdidchelper_p.h"
