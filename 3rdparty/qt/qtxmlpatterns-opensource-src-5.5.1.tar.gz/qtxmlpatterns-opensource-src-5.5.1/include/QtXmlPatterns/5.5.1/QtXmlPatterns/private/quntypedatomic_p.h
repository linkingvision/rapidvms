#include "../../../../../src/xmlpatterns/data/quntypedatomic_p.h"
