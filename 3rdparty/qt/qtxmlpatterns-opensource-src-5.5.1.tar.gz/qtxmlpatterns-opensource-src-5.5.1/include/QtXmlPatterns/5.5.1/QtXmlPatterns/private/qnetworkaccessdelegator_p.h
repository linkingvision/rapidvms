#include "../../../../../src/xmlpatterns/api/qnetworkaccessdelegator_p.h"
