#include "../../../../../src/xmlpatterns/iterators/qsequencemappingiterator_p.h"
