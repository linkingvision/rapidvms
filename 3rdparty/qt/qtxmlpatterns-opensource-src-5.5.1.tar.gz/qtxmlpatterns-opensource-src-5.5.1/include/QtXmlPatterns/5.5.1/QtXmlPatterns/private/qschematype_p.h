#include "../../../../../src/xmlpatterns/type/qschematype_p.h"
