#include "../../../../../src/xmlpatterns/type/quntyped_p.h"
