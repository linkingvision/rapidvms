#include "../../../../../src/xmlpatterns/api/qvariableloader_p.h"
