#include "../../../../../src/xmlpatterns/utils/qgenericnamespaceresolver_p.h"
