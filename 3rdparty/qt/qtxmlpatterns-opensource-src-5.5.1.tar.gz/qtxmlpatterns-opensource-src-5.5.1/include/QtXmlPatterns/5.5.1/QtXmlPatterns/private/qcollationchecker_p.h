#include "../../../../../src/xmlpatterns/expr/qcollationchecker_p.h"
