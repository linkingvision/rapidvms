#include "../../../../../src/xmlpatterns/environment/qstackcontextbase_p.h"
