#include "../../../../../src/xmlpatterns/type/qschemacomponent_p.h"
