#include "../../../../../src/xmlpatterns/iterators/qsubsequenceiterator_p.h"
