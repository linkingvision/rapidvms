#include "../../../../../src/xmlpatterns/data/qdecimal_p.h"
