#include "../../../../../src/xmlpatterns/data/qatomicmathematicians_p.h"
