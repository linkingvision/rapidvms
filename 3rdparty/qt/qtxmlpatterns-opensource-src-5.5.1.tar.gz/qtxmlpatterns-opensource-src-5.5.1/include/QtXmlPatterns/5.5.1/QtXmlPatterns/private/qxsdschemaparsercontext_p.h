#include "../../../../../src/xmlpatterns/schema/qxsdschemaparsercontext_p.h"
