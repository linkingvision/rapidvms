#include "../../../../../src/xmlpatterns/schema/qxsdassertion_p.h"
