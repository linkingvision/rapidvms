#include "../../../../../src/xmlpatterns/janitors/quntypedatomicconverter_p.h"
