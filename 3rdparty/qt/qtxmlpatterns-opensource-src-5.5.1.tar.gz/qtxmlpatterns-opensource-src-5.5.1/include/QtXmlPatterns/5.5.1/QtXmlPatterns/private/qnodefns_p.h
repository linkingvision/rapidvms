#include "../../../../../src/xmlpatterns/functions/qnodefns_p.h"
