#include "../../../../../src/xmlpatterns/utils/qpatternistlocale_p.h"
