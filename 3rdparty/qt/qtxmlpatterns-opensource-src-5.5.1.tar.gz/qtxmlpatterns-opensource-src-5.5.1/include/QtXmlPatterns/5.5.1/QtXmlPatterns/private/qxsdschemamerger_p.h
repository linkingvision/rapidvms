#include "../../../../../src/xmlpatterns/schema/qxsdschemamerger_p.h"
