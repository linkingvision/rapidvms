#include "../../../../../src/xmlpatterns/iterators/qindexofiterator_p.h"
