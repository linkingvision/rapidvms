#include "../../../../../src/xmlpatterns/environment/qdelegatingstaticcontext_p.h"
