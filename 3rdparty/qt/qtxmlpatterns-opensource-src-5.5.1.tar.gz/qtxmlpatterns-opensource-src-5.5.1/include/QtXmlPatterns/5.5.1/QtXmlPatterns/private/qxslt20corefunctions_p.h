#include "../../../../../src/xmlpatterns/functions/qxslt20corefunctions_p.h"
