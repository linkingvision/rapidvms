#include "../../../../../src/xmlpatterns/expr/qexternalvariablereference_p.h"
