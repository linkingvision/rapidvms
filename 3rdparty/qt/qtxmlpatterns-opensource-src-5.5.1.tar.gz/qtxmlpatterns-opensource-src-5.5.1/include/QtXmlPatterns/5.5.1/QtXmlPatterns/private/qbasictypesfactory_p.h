#include "../../../../../src/xmlpatterns/type/qbasictypesfactory_p.h"
