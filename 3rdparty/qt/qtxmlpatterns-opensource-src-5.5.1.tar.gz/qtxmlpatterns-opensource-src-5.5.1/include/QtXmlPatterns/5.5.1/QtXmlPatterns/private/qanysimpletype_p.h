#include "../../../../../src/xmlpatterns/type/qanysimpletype_p.h"
