#include "../../../../../src/xmlpatterns/type/qlocalnametest_p.h"
