#include "../../../../../src/xmlpatterns/type/qcardinality_p.h"
