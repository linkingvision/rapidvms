#include "../../../../../src/xmlpatterns/expr/qvariabledeclaration_p.h"
