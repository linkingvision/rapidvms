#include "../../../../../src/xmlpatterns/utils/qnodenamespaceresolver_p.h"
