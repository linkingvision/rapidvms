#include "../../../../../src/xmlpatterns/type/qatomicmathematicianlocator_p.h"
