#include "../../../../../src/xmlpatterns/expr/qtemplatepattern_p.h"
