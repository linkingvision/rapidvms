#include "../../../../../src/xmlpatterns/type/qatomiccomparatorlocator_p.h"
