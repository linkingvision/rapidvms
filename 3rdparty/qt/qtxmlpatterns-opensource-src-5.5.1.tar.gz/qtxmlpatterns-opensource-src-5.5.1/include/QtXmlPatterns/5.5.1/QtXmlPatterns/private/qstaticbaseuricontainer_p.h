#include "../../../../../src/xmlpatterns/functions/qstaticbaseuricontainer_p.h"
