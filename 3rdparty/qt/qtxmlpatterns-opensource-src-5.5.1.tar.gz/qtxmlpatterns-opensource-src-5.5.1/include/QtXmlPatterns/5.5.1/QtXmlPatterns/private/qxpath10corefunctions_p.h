#include "../../../../../src/xmlpatterns/functions/qxpath10corefunctions_p.h"
