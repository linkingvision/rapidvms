#include "../../../../../src/xmlpatterns/schema/qxsdannotated_p.h"
