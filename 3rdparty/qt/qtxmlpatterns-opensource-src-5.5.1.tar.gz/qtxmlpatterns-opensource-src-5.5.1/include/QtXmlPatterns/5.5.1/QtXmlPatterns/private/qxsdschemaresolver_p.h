#include "../../../../../src/xmlpatterns/schema/qxsdschemaresolver_p.h"
