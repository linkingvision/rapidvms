#include "../../../../../src/xmlpatterns/schema/qxsdschematoken_p.h"
