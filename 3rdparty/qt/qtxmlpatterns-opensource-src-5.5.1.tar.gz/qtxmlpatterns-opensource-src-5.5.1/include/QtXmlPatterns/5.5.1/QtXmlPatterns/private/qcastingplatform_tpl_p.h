#include "../../../../../src/xmlpatterns/expr/qcastingplatform_tpl_p.h"
