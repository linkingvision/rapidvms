#include "../../../../../src/xmlpatterns/type/qgenericsequencetype_p.h"
