#include "../../../../../src/xmlpatterns/type/qsequencetype_p.h"
