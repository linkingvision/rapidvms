#include "../../../../../src/xmlpatterns/schema/qxsdstatemachinebuilder_p.h"
