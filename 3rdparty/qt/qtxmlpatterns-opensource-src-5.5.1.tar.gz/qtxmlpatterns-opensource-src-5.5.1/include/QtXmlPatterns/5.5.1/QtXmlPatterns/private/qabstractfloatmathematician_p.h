#include "../../../../../src/xmlpatterns/data/qabstractfloatmathematician_p.h"
