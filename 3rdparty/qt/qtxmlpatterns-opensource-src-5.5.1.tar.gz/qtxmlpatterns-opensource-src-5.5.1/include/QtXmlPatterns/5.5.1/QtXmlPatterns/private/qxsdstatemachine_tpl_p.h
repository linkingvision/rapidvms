#include "../../../../../src/xmlpatterns/schema/qxsdstatemachine_tpl_p.h"
