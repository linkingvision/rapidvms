#include "../../../../../src/xmlpatterns/schema/qxsdschemahelper_p.h"
