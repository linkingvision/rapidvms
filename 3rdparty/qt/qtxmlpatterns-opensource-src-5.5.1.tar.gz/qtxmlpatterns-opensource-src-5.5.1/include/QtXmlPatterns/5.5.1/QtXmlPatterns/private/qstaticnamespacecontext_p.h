#include "../../../../../src/xmlpatterns/environment/qstaticnamespacecontext_p.h"
