#include "../../../../../src/xmlpatterns/functions/qcomparingaggregator_tpl_p.h"
