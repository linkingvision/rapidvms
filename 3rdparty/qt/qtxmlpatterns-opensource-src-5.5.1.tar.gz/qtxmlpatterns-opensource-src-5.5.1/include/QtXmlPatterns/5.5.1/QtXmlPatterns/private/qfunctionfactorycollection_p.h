#include "../../../../../src/xmlpatterns/functions/qfunctionfactorycollection_p.h"
