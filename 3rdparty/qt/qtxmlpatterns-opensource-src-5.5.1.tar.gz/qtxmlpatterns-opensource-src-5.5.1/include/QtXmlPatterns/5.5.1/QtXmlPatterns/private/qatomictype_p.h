#include "../../../../../src/xmlpatterns/type/qatomictype_p.h"
