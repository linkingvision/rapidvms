#include "../../../../../src/xmlpatterns/environment/qcurrentitemcontext_p.h"
