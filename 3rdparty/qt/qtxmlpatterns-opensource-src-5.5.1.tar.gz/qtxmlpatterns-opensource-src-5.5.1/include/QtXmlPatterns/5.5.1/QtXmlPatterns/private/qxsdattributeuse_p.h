#include "../../../../../src/xmlpatterns/schema/qxsdattributeuse_p.h"
