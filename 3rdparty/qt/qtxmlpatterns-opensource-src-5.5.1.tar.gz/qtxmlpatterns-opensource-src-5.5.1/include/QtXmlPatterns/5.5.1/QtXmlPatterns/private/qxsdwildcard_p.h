#include "../../../../../src/xmlpatterns/schema/qxsdwildcard_p.h"
