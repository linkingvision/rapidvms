#include "../../../../../src/xmlpatterns/functions/qcomparingaggregator_p.h"
