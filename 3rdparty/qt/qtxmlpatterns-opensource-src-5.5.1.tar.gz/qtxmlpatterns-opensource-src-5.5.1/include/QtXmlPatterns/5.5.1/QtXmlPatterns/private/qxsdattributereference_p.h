#include "../../../../../src/xmlpatterns/schema/qxsdattributereference_p.h"
