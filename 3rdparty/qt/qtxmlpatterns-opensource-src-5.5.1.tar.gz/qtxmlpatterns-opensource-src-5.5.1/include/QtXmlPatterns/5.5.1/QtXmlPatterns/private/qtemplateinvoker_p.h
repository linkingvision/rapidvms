#include "../../../../../src/xmlpatterns/expr/qtemplateinvoker_p.h"
