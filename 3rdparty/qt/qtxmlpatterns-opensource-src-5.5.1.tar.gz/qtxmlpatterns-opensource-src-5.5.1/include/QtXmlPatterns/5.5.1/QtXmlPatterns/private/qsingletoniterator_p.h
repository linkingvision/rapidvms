#include "../../../../../src/xmlpatterns/iterators/qsingletoniterator_p.h"
