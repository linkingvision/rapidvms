#include "../../../../../src/xmlpatterns/schema/qxsdalternative_p.h"
