#include "../../../../../src/xmlpatterns/functions/qdatetimefns_tpl_p.h"
