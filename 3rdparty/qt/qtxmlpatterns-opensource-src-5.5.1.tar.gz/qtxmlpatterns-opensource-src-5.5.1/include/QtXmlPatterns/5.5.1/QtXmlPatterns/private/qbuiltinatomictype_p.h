#include "../../../../../src/xmlpatterns/type/qbuiltinatomictype_p.h"
