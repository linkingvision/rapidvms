#include "../../../../../src/xmlpatterns/utils/qnamespaceresolver_p.h"
