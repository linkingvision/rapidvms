#include "../../../../../src/xmlpatterns/api/qresourcedelegator_p.h"
