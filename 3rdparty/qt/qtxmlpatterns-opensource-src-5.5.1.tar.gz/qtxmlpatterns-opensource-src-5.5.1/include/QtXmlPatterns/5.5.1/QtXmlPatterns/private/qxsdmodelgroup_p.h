#include "../../../../../src/xmlpatterns/schema/qxsdmodelgroup_p.h"
