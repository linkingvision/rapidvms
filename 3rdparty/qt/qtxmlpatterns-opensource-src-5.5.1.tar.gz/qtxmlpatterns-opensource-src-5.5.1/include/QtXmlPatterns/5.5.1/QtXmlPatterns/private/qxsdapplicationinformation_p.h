#include "../../../../../src/xmlpatterns/schema/qxsdapplicationinformation_p.h"
