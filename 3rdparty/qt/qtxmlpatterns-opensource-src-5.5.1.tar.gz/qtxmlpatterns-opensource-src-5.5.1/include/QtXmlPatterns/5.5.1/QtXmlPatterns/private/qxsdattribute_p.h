#include "../../../../../src/xmlpatterns/schema/qxsdattribute_p.h"
