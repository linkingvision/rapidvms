#include "../../../../../src/xmlpatterns/schema/qxsdparticlechecker_p.h"
