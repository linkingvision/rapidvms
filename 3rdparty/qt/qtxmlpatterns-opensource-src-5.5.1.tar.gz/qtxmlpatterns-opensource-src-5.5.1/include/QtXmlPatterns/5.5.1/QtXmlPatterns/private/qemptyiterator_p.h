#include "../../../../../src/xmlpatterns/iterators/qemptyiterator_p.h"
