#include "../../../../../src/xmlpatterns/environment/qstackcontextbase_tpl_p.h"
