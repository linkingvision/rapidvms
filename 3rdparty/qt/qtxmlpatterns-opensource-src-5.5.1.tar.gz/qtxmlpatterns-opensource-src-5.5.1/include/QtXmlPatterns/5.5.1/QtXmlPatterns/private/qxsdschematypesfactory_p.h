#include "../../../../../src/xmlpatterns/schema/qxsdschematypesfactory_p.h"
