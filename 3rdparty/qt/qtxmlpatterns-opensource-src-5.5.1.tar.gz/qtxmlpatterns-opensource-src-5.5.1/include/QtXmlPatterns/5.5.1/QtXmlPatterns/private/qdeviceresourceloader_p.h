#include "../../../../../src/xmlpatterns/api/qdeviceresourceloader_p.h"
