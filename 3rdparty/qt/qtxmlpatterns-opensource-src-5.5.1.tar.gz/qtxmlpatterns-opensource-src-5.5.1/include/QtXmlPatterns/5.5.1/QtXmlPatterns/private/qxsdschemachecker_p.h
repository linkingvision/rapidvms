#include "../../../../../src/xmlpatterns/schema/qxsdschemachecker_p.h"
