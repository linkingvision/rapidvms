#include "../../../../../src/xmlpatterns/expr/qgeneralcomparison_p.h"
