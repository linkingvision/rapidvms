#include "../../../../../src/xmlpatterns/functions/qsequencegeneratingfns_p.h"
