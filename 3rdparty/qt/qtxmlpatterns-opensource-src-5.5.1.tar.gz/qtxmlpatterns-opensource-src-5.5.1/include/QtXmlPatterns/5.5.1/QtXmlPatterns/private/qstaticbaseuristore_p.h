#include "../../../../../src/xmlpatterns/expr/qstaticbaseuristore_p.h"
