#include "../../../../../src/xmlpatterns/expr/qtemplatemode_p.h"
