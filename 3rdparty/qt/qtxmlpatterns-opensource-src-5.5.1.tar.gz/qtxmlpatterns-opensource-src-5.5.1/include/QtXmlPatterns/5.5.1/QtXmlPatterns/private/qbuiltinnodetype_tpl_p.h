#include "../../../../../src/xmlpatterns/type/qbuiltinnodetype_tpl_p.h"
