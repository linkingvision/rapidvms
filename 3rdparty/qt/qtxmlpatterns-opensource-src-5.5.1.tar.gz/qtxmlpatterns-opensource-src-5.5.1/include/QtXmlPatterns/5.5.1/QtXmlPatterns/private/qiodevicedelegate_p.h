#include "../../../../../src/xmlpatterns/api/qiodevicedelegate_p.h"
