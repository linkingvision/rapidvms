#include "../../../../../src/xmlpatterns/utils/qnamespacebinding_p.h"
