#include "../../../../../src/xmlpatterns/data/qabstractfloat_tpl_p.h"
