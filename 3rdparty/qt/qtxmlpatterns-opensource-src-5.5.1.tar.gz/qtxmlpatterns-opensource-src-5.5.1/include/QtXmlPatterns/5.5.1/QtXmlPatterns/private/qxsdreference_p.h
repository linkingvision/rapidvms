#include "../../../../../src/xmlpatterns/schema/qxsdreference_p.h"
