#include "../../../../../src/xmlpatterns/functions/qpatternplatform_p.h"
