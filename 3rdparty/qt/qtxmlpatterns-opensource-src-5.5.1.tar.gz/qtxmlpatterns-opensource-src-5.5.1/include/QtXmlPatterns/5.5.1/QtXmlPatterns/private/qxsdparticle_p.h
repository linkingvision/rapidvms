#include "../../../../../src/xmlpatterns/schema/qxsdparticle_p.h"
