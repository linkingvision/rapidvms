#include "../../../../../src/xmlpatterns/data/qresourceloader_p.h"
