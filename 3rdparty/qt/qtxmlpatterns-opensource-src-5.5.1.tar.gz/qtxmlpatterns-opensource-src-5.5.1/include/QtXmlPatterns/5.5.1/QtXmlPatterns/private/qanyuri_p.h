#include "../../../../../src/xmlpatterns/data/qanyuri_p.h"
