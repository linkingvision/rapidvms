#include "../../../../../src/xmlpatterns/functions/qfunctionavailablefn_p.h"
