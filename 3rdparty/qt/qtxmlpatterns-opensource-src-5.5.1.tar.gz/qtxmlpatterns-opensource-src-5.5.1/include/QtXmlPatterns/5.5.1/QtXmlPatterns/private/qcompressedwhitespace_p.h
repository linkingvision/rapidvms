#include "../../../../../src/xmlpatterns/acceltree/qcompressedwhitespace_p.h"
