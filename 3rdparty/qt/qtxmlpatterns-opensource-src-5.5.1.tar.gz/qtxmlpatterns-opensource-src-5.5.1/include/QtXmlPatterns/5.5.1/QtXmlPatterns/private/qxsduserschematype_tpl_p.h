#include "../../../../../src/xmlpatterns/schema/qxsduserschematype_tpl_p.h"
