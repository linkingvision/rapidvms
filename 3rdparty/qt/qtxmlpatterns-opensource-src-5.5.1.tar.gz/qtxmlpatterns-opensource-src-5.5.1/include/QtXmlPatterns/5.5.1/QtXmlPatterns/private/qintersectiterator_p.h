#include "../../../../../src/xmlpatterns/iterators/qintersectiterator_p.h"
