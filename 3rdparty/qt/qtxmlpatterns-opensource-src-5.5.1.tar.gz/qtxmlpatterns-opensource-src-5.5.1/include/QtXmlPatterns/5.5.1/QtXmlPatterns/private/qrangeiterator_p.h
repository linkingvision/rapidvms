#include "../../../../../src/xmlpatterns/iterators/qrangeiterator_p.h"
