#include "../../../../../src/xmlpatterns/schema/qnamespacesupport_p.h"
