#include "../../../../../src/xmlpatterns/data/qhexbinary_p.h"
