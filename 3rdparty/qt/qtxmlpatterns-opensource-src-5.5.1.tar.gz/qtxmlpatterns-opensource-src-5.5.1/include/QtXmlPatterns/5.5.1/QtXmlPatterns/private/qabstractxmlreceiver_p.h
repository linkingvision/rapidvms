#include "../../../../../src/xmlpatterns/api/qabstractxmlreceiver_p.h"
