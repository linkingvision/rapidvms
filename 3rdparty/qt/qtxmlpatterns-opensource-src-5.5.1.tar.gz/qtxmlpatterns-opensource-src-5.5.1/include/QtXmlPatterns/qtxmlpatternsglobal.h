#include "../../src/xmlpatterns/api/qtxmlpatternsglobal.h"
