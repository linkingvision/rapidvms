//gsoap ck service name: ckdbtest
//gsoap ck service location: http://www.cs.fsu.edu/~engelen
//gsoap ck service namespace: http://www.cs.fsu.edu/~engelen/ck.wsdl
//gsoap ck service encoding: encoded
//gsoap ck schema  namespace: urn:ck
int ck__demo(char **r);
